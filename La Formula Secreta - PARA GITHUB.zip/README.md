# La Fórmula Secreta 🌐

Landing page de hamburguesas con pedido por WhatsApp, carrito interactivo, PWA y efectos 3D. Proyecto 100% estático: no necesita build ni dependencias.

## Archivos incluidos

| Archivo | Para qué sirve |
| --- | --- |
| `index.html` | Página completa (HTML + CSS + JS + logo embebido). |
| `manifest.webmanifest` | Manifest de la PWA (nombre, colores, iconos). |
| `sw.js` | Service worker para que funcione offline. |
| `icon-192.png` / `icon-512.jpg` | Iconos de la app. |
| `.nojekyll` | Evita que GitHub Pages ignore archivos especiales. |

## Subirlo a GitHub desde la web (sin instalar git)

1. Entrá a https://github.com/new y creá un repositorio nuevo (por ejemplo `la-formula-secreta`). Dejalo **Public**.
2. Dentro del repo, tocá **Add file → Upload files**.
3. Arrastrá **todos** los archivos de esta carpeta (incluido `.nojekyll`; en Windows puede ser invisible, mostralo con `Ver → Elementos ocultos`).
4. Escribí un mensaje de commit, por ejemplo `Initial commit - landing La Fórmula Secreta`, y tocá **Commit changes**.

## Activar GitHub Pages (para que tenga URL pública)

1. En el repo: **Settings → Pages**.
2. En *Build and deployment*, elegí **Deploy from a branch**.
3. Branch: `main` (o `master`) y carpeta: **/ (root)**. Guardá.
4. En 1–2 minutos la página va a estar en:
   `https://TU-USUARIO.github.io/NOMBRE-REPO/`

> La URL depende del nombre del repositorio. Si el repo se llama `la-formula-secreta`, queda `https://tu-usuario.github.io/la-formula-secreta/`.

## Si después instalás git

```bash
git init
git add .
git commit -m "Initial commit - landing La Fórmula Secreta"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/NOMBRE-REPO.git
git push -u origin main
```

## Recordatorios antes de publicar

- El número de WhatsApp es `5492216561269` (está en todos los links `wa.me`).
- Cada hamburguesa cuesta **$8.000 con papas incluidas**; la porción extra de papas es **$1.500**.
- Falta el código de barras de Naranja X: buscar el elemento con `id="payBarcode"` en `index.html` y reemplazar el placeholder por la imagen.
- Verificá en el celular: PWA instalable, botón de WhatsApp y modo "reducir movimiento".
